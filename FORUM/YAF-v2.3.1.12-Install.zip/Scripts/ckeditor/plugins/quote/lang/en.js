﻿CKEDITOR.plugins.setLang("quote","en",
    {
        title: "Quote"
    });