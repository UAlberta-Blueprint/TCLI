﻿CKEDITOR.plugins.setLang("attachments","en",{
	title: "Select or Upload an Attachment",
	loading: "Loading Attachments",
	noAlbums: "You don't have any attachments yet, to add one click on the &lt;strong&gt;Upload New File(s)&lt;/strong&gt; button",
	upload: "Upload New File(s)"
});