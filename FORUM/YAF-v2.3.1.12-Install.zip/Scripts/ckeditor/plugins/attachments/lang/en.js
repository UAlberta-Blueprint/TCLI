﻿CKEDITOR.plugins.setLang("albumsbrowser","en",{
	title: "Select an Album Image",
	loading: "Loading Images",
	noAlbums: "You havent uploaded any User Albums"
});