﻿CKEDITOR.plugins.setLang("highlight","en",
    {
        title: "Highlight Text"
    });